# frozen_string_literal: true

require 'json'
require 'base64'
require 'aws-sdk-s3'

# TEST_DATA = {"Records"=>[{"kinesis"=>{"kinesisSchemaVersion"=>"1.0", "partitionKey"=>"9763FB006534CBB491EC298AE82E2E2B", "sequenceNumber"=>"49638593883006309589553171796803341729009017655991992322", "data"=>"eyJhd3NSZWdpb24iOiJ1cy1lYXN0LTEiLCJldmVudElEIjoiOTNhN2QwMzAtNTJmYS00ZDYzLTkwNDAtMTAyZmFhYTZhYWZkIiwiZXZlbnROYW1lIjoiSU5TRVJUIiwidXNlcklkZW50aXR5IjpudWxsLCJyZWNvcmRGb3JtYXQiOiJhcHBsaWNhdGlvbi9qc29uIiwidGFibGVOYW1lIjoiU2hvcHBpbmdDYXJ0cyIsImR5bmFtb2RiIjp7IkFwcHJveGltYXRlQ3JlYXRpb25EYXRlVGltZSI6MTY3ODAyMjYzODMyOCwiS2V5cyI6eyJVdWlkIjp7IlMiOiI2ODBiMDI5Mi0wNzcyLTQwOWYtYTJlNi1mMGYwOGUzYWU5ZGYifX0sIk5ld0ltYWdlIjp7IkV2ZW50cyI6eyJMIjpbeyJNIjp7IkRhdGEiOnsiTSI6eyJzaG9wcGluZ19jYXJ0X3V1aWQiOnsiUyI6IjY4MGIwMjkyLTA3NzItNDA5Zi1hMmU2LWYwZjA4ZTNhZTlkZiJ9fX0sIk5hbWUiOnsiUyI6IkNhcnRPcGVuZWQifX19XX0sIlV1aWQiOnsiUyI6IjY4MGIwMjkyLTA3NzItNDA5Zi1hMmU2LWYwZjA4ZTNhZTlkZiJ9fSwiU2l6ZUJ5dGVzIjoxNzF9LCJldmVudFNvdXJjZSI6ImF3czpkeW5hbW9kYiJ9", "approximateArrivalTimestamp"=>1678022638.604}, "eventSource"=>"aws:kinesis", "eventVersion"=>"1.0", "eventID"=>"shardId-000000000000:49638593883006309589553171796803341729009017655991992322", "eventName"=>"aws:kinesis:record", "invokeIdentityArn"=>"arn:aws:iam::311476293586:role/s3_event_logger-role-for-lambda", "awsRegion"=>"us-east-1", "eventSourceARN"=>"arn:aws:kinesis:us-east-1:311476293586:stream/event_stream"}]}

def pluck_kinesis_change_events(event)
  event
    .fetch('Records')
    .map { |source| source.fetch('kinesis', nil) }
    .reject(&:nil?)
    .map { |k| [k.fetch('sequenceNumber'), Base64.decode64(k.fetch('data'))] }
    .reject { |_, event| event.nil? }
end

def handler(event:, context:)
  s3_bucket = Aws::S3::Resource.new.bucket(ENV['s3_bucket_name'])

  pluck_kinesis_change_events(event).each do |event_id, event|
    s3_bucket.put_object(
      body: event,
      key: event_id
    )
  end

  { event: JSON.generate(event), context: JSON.generate(context.inspect) }
end
